require 'twitter'

client = Twitter::REST::Client.new do |config|
   config.consumer_key = '82eykNWaYrWgd8f03imtentGI'
   config.consumer_secret     = "XmE3Ixl0bT7RtITN6zD5EpwjnD4W0wELjP91AlwcdoAEXe70Lp"
   config.access_token        = "933378794961895425-OzG8kor1GZAFYVKtRByLyNVIKCFc2Vh"
   config.access_token_secret = "d3ZFKjzPwE4vdvbr6NULmo1c1uDPjC48CsHO6CaEj0sEV"
end


     #<% client.search("to:overwatch", result_type: "recent").take(3).collect do |tweet|
     #"#{tweet.user.screen_name}: #{tweet.text}"
     #end %>
